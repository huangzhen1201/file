/*
Navicat MySQL Data Transfer

Source Server         : 本地MySQL5.7
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : unngroup

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2018-05-01 00:00:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for building
-- ----------------------------
DROP TABLE IF EXISTS `building`;
CREATE TABLE `building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `img_id` int(11) NOT NULL,
  `layout_ids` varchar(100) DEFAULT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of building
-- ----------------------------
INSERT INTO `building` VALUES ('1', '深圳湾', '85', '1,4,5', null, null, null);
INSERT INTO `building` VALUES ('2', '地导弹', '86', '1,3,5', null, null, null);
INSERT INTO `building` VALUES ('3', '枫林晚', '87', '1,4,5,8,9,11,12,13,14,15', null, null, null);
INSERT INTO `building` VALUES ('5', '方式发', '100', '6,7', null, null, null);
INSERT INTO `building` VALUES ('6', '小二楼', '129', '4,8,18', null, null, null);

-- ----------------------------
-- Table structure for consumer
-- ----------------------------
DROP TABLE IF EXISTS `consumer`;
CREATE TABLE `consumer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `wechart_id` varchar(50) DEFAULT NULL,
  `wechart_name` varchar(255) DEFAULT NULL,
  `reg_time` bigint(20) NOT NULL,
  `v1` varchar(255) DEFAULT NULL,
  `v2` varchar(255) DEFAULT NULL,
  `v3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of consumer
-- ----------------------------
INSERT INTO `consumer` VALUES ('4', '黄大帅', '13682430950', '574401729@qq.com', null, null, '1524420838464', null, null, null);
INSERT INTO `consumer` VALUES ('5', '哈哈大奖', '15818522212', '1124546@qq.com', null, null, '1524449731386', null, null, null);
INSERT INTO `consumer` VALUES ('6', '武大', '1311111111', '100000@qq.com', null, null, '1524471799345', null, null, null);
INSERT INTO `consumer` VALUES ('7', '后卫', '15888888888', '54545555@qq.com', null, null, '1524475167319', null, null, null);

-- ----------------------------
-- Table structure for designer
-- ----------------------------
DROP TABLE IF EXISTS `designer`;
CREATE TABLE `designer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `img_id` int(11) DEFAULT NULL,
  `synopsis` varchar(800) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of designer
-- ----------------------------
INSERT INTO `designer` VALUES ('1', 'ssssss', '4', 'sdadsadasdas', null, null, null, null);
INSERT INTO `designer` VALUES ('3', '孙大圣', '74', '“我的设计不求仰慕者，但求知心人”，生活就应该有它的品味——ALVIN GRASSI是这样描述自己的作品的。\r\n    2008年7月，意大利玛丽嘉儿杂志Marie Claire Maison以“照亮远见”来定义他。\r\n大胆创新，用他敏锐的视觉去感知，他从不错过每一个有诗意的瞬间。复古的风格对他的作品影响很大。在与Alberta Ferretti以及一些时尚设计师合作后，他在设计的世界里找到了新的生命。他设计风格奢华而不低俗，古典而又时尚。他的设计领域还涉及酒店、会所、私宅等。', null, null, null, null);
INSERT INTO `designer` VALUES ('4', 'a', '8', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', null, null, null, null);
INSERT INTO `designer` VALUES ('5', 'b', '9', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', null, null, null, null);
INSERT INTO `designer` VALUES ('6', 'c', '10', 'ccccccccccccccccccccccccccc', null, null, null, null);
INSERT INTO `designer` VALUES ('7', 'd', '11', 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', null, null, null, null);
INSERT INTO `designer` VALUES ('8', 'e', '12', 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', null, null, null, null);
INSERT INTO `designer` VALUES ('9', 'f', '13', 'fffffffffffffffffffffffffffffffffff', null, null, null, null);
INSERT INTO `designer` VALUES ('10', 'g', '14', 'ggggggggggggggggggggg', null, null, null, null);
INSERT INTO `designer` VALUES ('11', 'h', '15', 'hhhhhhhhhhh', null, null, null, null);
INSERT INTO `designer` VALUES ('12', 'ii', '19', 'iiiiiiiiii', null, null, null, null);
INSERT INTO `designer` VALUES ('16', 'm', '26', 'xczd', null, null, null, null);
INSERT INTO `designer` VALUES ('17', 'nn', '29', 'dsadsads', null, null, null, null);
INSERT INTO `designer` VALUES ('18', 'uu', '30', 'uuuuuuuuuuuuuuuuuuuuu', null, null, null, null);
INSERT INTO `designer` VALUES ('19', 'sda', '32', '', null, null, null, null);
INSERT INTO `designer` VALUES ('20', '华天夏', '133', '这个很帅惨了', null, null, null, null);
INSERT INTO `designer` VALUES ('21', '立马', '134', '大苏打撒旦\r\n的撒大苏打啊啊啊\r\nasdsdasd \r\n啊实打实大苏打的', null, null, null, null);

-- ----------------------------
-- Table structure for furniture
-- ----------------------------
DROP TABLE IF EXISTS `furniture`;
CREATE TABLE `furniture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `img_id` int(11) DEFAULT NULL,
  `material_ids` varchar(11) DEFAULT NULL,
  `brand` varchar(80) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `w` double DEFAULT NULL,
  `l` double DEFAULT NULL,
  `h` double DEFAULT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of furniture
-- ----------------------------
INSERT INTO `furniture` VALUES ('2', '凳子', null, '', '宜家', null, '100', '120', '80', null, null, null, '[{\"id\":20,\"price\":5000.123,\"imgId\":\"115\"},{\"id\":18,\"price\":4500.25,\"imgId\":\"116\"}]');
INSERT INTO `furniture` VALUES ('3', '餐桌', null, '', '宜家', null, '150', '210', '110', null, null, null, '[{\"id\":16,\"price\":25452547852,\"imgId\":\"117\"},{\"id\":12,\"price\":23,\"imgId\":\"118\"}]');
INSERT INTO `furniture` VALUES ('4', '书桌', null, '7,8', '木易', null, '80', '150', '110', null, null, null, '[{\"id\":8,\"price\":4000,\"imgId\":\"113\"},{\"id\":7,\"price\":4800,\"imgId\":\"114\"}]');
INSERT INTO `furniture` VALUES ('5', '储物柜', null, '1,4,5', '小鸟', null, '110', '120', '200', null, null, null, '[{\"id\":1,\"price\":1111,\"imgId\":\"110\"},{\"id\":4,\"price\":2222,\"imgId\":\"111\"},{\"id\":5,\"price\":3333,\"imgId\":\"112\"}]');
INSERT INTO `furniture` VALUES ('6', '冰箱', null, '1,4,5,6', '海尔', null, '80', '80', '200', null, null, null, '[{\"id\":1,\"price\":2000.33,\"imgId\":\"121\"},{\"id\":4,\"price\":2050.22,\"imgId\":\"108\"},{\"id\":5,\"price\":2100.11,\"imgId\":\"109\"},{\"id\":6,\"price\":2255,\"imgId\":\"122\"}]');
INSERT INTO `furniture` VALUES ('7', '方桌', null, '4', '宜家', null, '100', '100', '80', null, null, null, '[{\"id\":4,\"price\":10000,\"imgId\":\"130\"}]');
INSERT INTO `furniture` VALUES ('8', '小衣橱', null, '2,7', '宜家', null, '100', '200', '100', null, null, null, '[{\"id\":2,\"price\":1000,\"imgId\":\"138\"},{\"id\":7,\"price\":2000,\"imgId\":\"139\"}]');

-- ----------------------------
-- Table structure for images
-- ----------------------------
DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `v1` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of images
-- ----------------------------
INSERT INTO `images` VALUES ('4', 'dea5550b-83ef-3bf8-8448-0339a155d538.jpg', null);
INSERT INTO `images` VALUES ('5', '2aa5e480-3c7d-37d8-97a0-cb218ef7646e.jpg', null);
INSERT INTO `images` VALUES ('6', '2aa5e480-3c7d-37d8-97a0-cb218ef7646e.jpg', null);
INSERT INTO `images` VALUES ('7', 'bb92ef37-592e-3915-9016-68809e37ae27.jpg', null);
INSERT INTO `images` VALUES ('8', 'bb92ef37-592e-3915-9016-68809e37ae27.jpg', null);
INSERT INTO `images` VALUES ('9', '6e10340d-0e0b-37f4-b027-dd25d65113d9.jpg', null);
INSERT INTO `images` VALUES ('10', '59888f3a-eeb6-3467-a8a5-1946f9d2e5a2.jpg', null);
INSERT INTO `images` VALUES ('11', '8e49bfa1-5515-3257-bd79-5c51ea4ac314.jpg', null);
INSERT INTO `images` VALUES ('12', '2dd0c6fc-40af-345a-9c53-d07a610c73fd.jpg', null);
INSERT INTO `images` VALUES ('13', '12fe9478-2c2e-3e2d-8936-8e7cfce04869.jpg', null);
INSERT INTO `images` VALUES ('14', '8859d5e2-fc1d-378f-b24d-379eb17606d2.jpg', null);
INSERT INTO `images` VALUES ('15', '8ff23cc4-898d-3849-aeb2-97dd6a5a3201.jpg', null);
INSERT INTO `images` VALUES ('16', 'eb2ba38f-4640-3210-b9d2-88e72a3f5e84.JPG', null);
INSERT INTO `images` VALUES ('17', '1565a453-5d7e-3a1f-96e8-69a536703dac.jpg', null);
INSERT INTO `images` VALUES ('18', 'a792dd78-b15e-389d-a57a-d0ad53bef0b9.jpg', null);
INSERT INTO `images` VALUES ('19', '6e10340d-0e0b-37f4-b027-dd25d65113d9.jpg', null);
INSERT INTO `images` VALUES ('20', '8ee6d759-b08c-3047-b3f1-30febc383271.jpg', null);
INSERT INTO `images` VALUES ('21', '47eeeebc-a232-373b-b6dd-fd8f4721580b.jpg', null);
INSERT INTO `images` VALUES ('22', '8ca82a28-8680-31dd-95d7-9d28bbdeac77.jpg', null);
INSERT INTO `images` VALUES ('23', '2e59b029-978d-3ebd-9e1c-cfe481af9862.jpg', null);
INSERT INTO `images` VALUES ('24', 'f682059f-fd21-3513-bddf-d09799702ae2.jpg', null);
INSERT INTO `images` VALUES ('25', '92173815-75ab-38cd-a580-776d52cdb6ea.jpg', null);
INSERT INTO `images` VALUES ('26', '3e6cc5cd-b7a7-3b6e-b6cd-697561be6fee.jpg', null);
INSERT INTO `images` VALUES ('27', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('28', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('29', '8a90542e-6a1a-343f-a7df-e55b3db53cb1.jpg', null);
INSERT INTO `images` VALUES ('30', 'ad696e5a-7311-3d2f-a9d4-5a3b02df4652.jpg', null);
INSERT INTO `images` VALUES ('31', '67b5c10c-d03b-3bbe-8f25-6c263550602d.jpg', null);
INSERT INTO `images` VALUES ('32', 'a101d903-f4ae-3b7b-b2f3-dac04ab58a23.jpg', null);
INSERT INTO `images` VALUES ('33', '7bd1c552-e04e-3070-b4bc-a8587a108a8f.jpg', null);
INSERT INTO `images` VALUES ('34', '7c9c9524-d8b5-3fcf-8e22-e930e62d16db.jpg', null);
INSERT INTO `images` VALUES ('35', 'c1844dba-06fc-3d3d-9fcc-ff4c2d6e2f05.jpg', null);
INSERT INTO `images` VALUES ('36', '61b4af0f-1d52-34db-9862-eae797ea892e.jpg', null);
INSERT INTO `images` VALUES ('37', '2aa5e480-3c7d-37d8-97a0-cb218ef7646e.jpg', null);
INSERT INTO `images` VALUES ('38', '61b4af0f-1d52-34db-9862-eae797ea892e.jpg', null);
INSERT INTO `images` VALUES ('39', '2aa5e480-3c7d-37d8-97a0-cb218ef7646e.jpg', null);
INSERT INTO `images` VALUES ('40', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('41', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('42', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('43', '68076692-0c64-35dd-a442-5ba939fa8384.jpg', null);
INSERT INTO `images` VALUES ('44', 'ff3b02be-b351-3684-ab91-7be0830e7a2c.jpg', null);
INSERT INTO `images` VALUES ('45', 'd7a0abc5-7e68-322a-b678-a657eb21d588.jpg', null);
INSERT INTO `images` VALUES ('46', 'fb3ad05e-7f26-3359-9cec-2c7f7f19f22d.jpg', null);
INSERT INTO `images` VALUES ('47', 'ca5f0576-02ba-3425-8943-b807409d2d15.jpg', null);
INSERT INTO `images` VALUES ('48', '3e6cc5cd-b7a7-3b6e-b6cd-697561be6fee.jpg', null);
INSERT INTO `images` VALUES ('49', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('50', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('51', '8ad184ff-7cb1-3f04-9a59-26273c1441f6.jpg', null);
INSERT INTO `images` VALUES ('52', '6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg', null);
INSERT INTO `images` VALUES ('53', '6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg', null);
INSERT INTO `images` VALUES ('54', '9894e3e5-f9bc-31f6-9718-23cfe6e2594c.jpg', null);
INSERT INTO `images` VALUES ('55', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('56', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('57', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('58', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('59', 'ad696e5a-7311-3d2f-a9d4-5a3b02df4652.jpg', null);
INSERT INTO `images` VALUES ('60', 'ec4ca5b3-37ff-3f2e-aad6-613d235b65c9.jpg', null);
INSERT INTO `images` VALUES ('61', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('62', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('63', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('64', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('65', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('66', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('67', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('68', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('69', '9894e3e5-f9bc-31f6-9718-23cfe6e2594c.jpg', null);
INSERT INTO `images` VALUES ('70', 'd7a0abc5-7e68-322a-b678-a657eb21d588.jpg', null);
INSERT INTO `images` VALUES ('71', '8a90542e-6a1a-343f-a7df-e55b3db53cb1.jpg', null);
INSERT INTO `images` VALUES ('72', '8ad184ff-7cb1-3f04-9a59-26273c1441f6.jpg', null);
INSERT INTO `images` VALUES ('73', 'ec4ca5b3-37ff-3f2e-aad6-613d235b65c9.jpg', null);
INSERT INTO `images` VALUES ('74', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('75', '2aa5e480-3c7d-37d8-97a0-cb218ef7646e.jpg', null);
INSERT INTO `images` VALUES ('76', 'b1bb1540-b7f8-3ab8-8487-f835a353b216.png', null);
INSERT INTO `images` VALUES ('77', '239f15c2-89dc-3591-9dc2-26b07c871991.png', null);
INSERT INTO `images` VALUES ('78', 'b8806d73-0d7c-3ec2-9ac6-527a11b820a2.png', null);
INSERT INTO `images` VALUES ('79', '26c4b963-11dc-36cf-a3ce-3677518c2944.jpg', null);
INSERT INTO `images` VALUES ('80', 'e3053b2f-89e6-30df-9c7b-516130bea14d.jpg', null);
INSERT INTO `images` VALUES ('81', '2642f16e-6f3d-319e-9a97-fe98230fa8c4.jpg', null);
INSERT INTO `images` VALUES ('82', 'dc847717-c886-3d86-ab37-0e02309e7799.jpg', null);
INSERT INTO `images` VALUES ('83', '68819755-1f3f-3338-904c-c29de2305f1e.jpg', null);
INSERT INTO `images` VALUES ('84', '086077d8-aa9d-332f-9462-02a4403bd74b.jpg', null);
INSERT INTO `images` VALUES ('85', '5429e73a-23a3-3bf9-9c38-0ed3deb6c37b.jpg', null);
INSERT INTO `images` VALUES ('86', '2642f16e-6f3d-319e-9a97-fe98230fa8c4.jpg', null);
INSERT INTO `images` VALUES ('87', '84add258-90b6-3096-a57f-beecfa325945.jpg', null);
INSERT INTO `images` VALUES ('88', '9894e3e5-f9bc-31f6-9718-23cfe6e2594c.jpg', null);
INSERT INTO `images` VALUES ('89', 'c1844dba-06fc-3d3d-9fcc-ff4c2d6e2f05.jpg', null);
INSERT INTO `images` VALUES ('90', '3e1b26cd-b350-3b27-ac23-a77220ba6cbb.jpg', null);
INSERT INTO `images` VALUES ('91', '3e6cc5cd-b7a7-3b6e-b6cd-697561be6fee.jpg', null);
INSERT INTO `images` VALUES ('92', '68819755-1f3f-3338-904c-c29de2305f1e.jpg', null);
INSERT INTO `images` VALUES ('93', 'ad696e5a-7311-3d2f-a9d4-5a3b02df4652.jpg', null);
INSERT INTO `images` VALUES ('94', 'ca5f0576-02ba-3425-8943-b807409d2d15.jpg', null);
INSERT INTO `images` VALUES ('95', 'ff3b02be-b351-3684-ab91-7be0830e7a2c.jpg', null);
INSERT INTO `images` VALUES ('96', 'c8d78ea3-6ce0-329c-809f-475ec12de3ae.jpg', null);
INSERT INTO `images` VALUES ('97', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('98', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('99', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('100', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('101', '84fe4c99-8dad-3faf-bde9-cb775d1e29e8.jpg', null);
INSERT INTO `images` VALUES ('102', '29ea1f17-19a0-3f2f-b969-43b49a3e23ef.jpg', null);
INSERT INTO `images` VALUES ('103', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('104', '2f69390b-c2c3-3bec-8a49-be40d459501a.jpg', null);
INSERT INTO `images` VALUES ('105', '366215b9-9b65-3fa5-b3a1-294286326439.jpg', null);
INSERT INTO `images` VALUES ('106', 'ca5f0576-02ba-3425-8943-b807409d2d15.jpg', null);
INSERT INTO `images` VALUES ('107', 'ad696e5a-7311-3d2f-a9d4-5a3b02df4652.jpg', null);
INSERT INTO `images` VALUES ('108', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('109', 'd7a0abc5-7e68-322a-b678-a657eb21d588.jpg', null);
INSERT INTO `images` VALUES ('110', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('111', 'ec4ca5b3-37ff-3f2e-aad6-613d235b65c9.jpg', null);
INSERT INTO `images` VALUES ('112', '6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg', null);
INSERT INTO `images` VALUES ('113', '6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg', null);
INSERT INTO `images` VALUES ('114', '2642f16e-6f3d-319e-9a97-fe98230fa8c4.jpg', null);
INSERT INTO `images` VALUES ('115', 'ca5f0576-02ba-3425-8943-b807409d2d15.jpg', null);
INSERT INTO `images` VALUES ('116', 'c8d78ea3-6ce0-329c-809f-475ec12de3ae.jpg', null);
INSERT INTO `images` VALUES ('117', 'b98a9df7-1603-351d-871e-65aa4386e876.jpg', null);
INSERT INTO `images` VALUES ('118', '6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg', null);
INSERT INTO `images` VALUES ('119', 'ff3b02be-b351-3684-ab91-7be0830e7a2c.jpg', null);
INSERT INTO `images` VALUES ('120', 'ca5f0576-02ba-3425-8943-b807409d2d15.jpg', null);
INSERT INTO `images` VALUES ('121', '366215b9-9b65-3fa5-b3a1-294286326439.jpg', null);
INSERT INTO `images` VALUES ('122', 'c8d78ea3-6ce0-329c-809f-475ec12de3ae.jpg', null);
INSERT INTO `images` VALUES ('123', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('124', '9e7e3402-5ebe-30ed-99ed-c38b02d45906.jpg', null);
INSERT INTO `images` VALUES ('125', '8a90542e-6a1a-343f-a7df-e55b3db53cb1.jpg', null);
INSERT INTO `images` VALUES ('126', '2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg', null);
INSERT INTO `images` VALUES ('127', 'ff3b02be-b351-3684-ab91-7be0830e7a2c.jpg', null);
INSERT INTO `images` VALUES ('128', 'af72e0e2-2b2b-3da1-8faa-ece063fc34f0.jpg', null);
INSERT INTO `images` VALUES ('129', '68819755-1f3f-3338-904c-c29de2305f1e.jpg', null);
INSERT INTO `images` VALUES ('130', 'af72e0e2-2b2b-3da1-8faa-ece063fc34f0.jpg', null);
INSERT INTO `images` VALUES ('131', '4e2c62ae-f603-310e-921d-c1c90d994ed5.jpg', null);
INSERT INTO `images` VALUES ('132', 'a50ce3ab-349d-393d-b938-5a73c9fd95c0.jpg', null);
INSERT INTO `images` VALUES ('133', '0c829ba9-cdb7-3c36-8389-8778c8d1820a.jpg', null);
INSERT INTO `images` VALUES ('134', 'b4fe8961-a7b1-31de-8d84-52b3fb2a284e.jpg', null);
INSERT INTO `images` VALUES ('135', '239f15c2-89dc-3591-9dc2-26b07c871991.png', null);
INSERT INTO `images` VALUES ('136', 'b8806d73-0d7c-3ec2-9ac6-527a11b820a2.png', null);
INSERT INTO `images` VALUES ('137', 'f00029b0-0cd1-3a03-bd40-4d590d18e82d.png', null);
INSERT INTO `images` VALUES ('138', '3e1b26cd-b350-3b27-ac23-a77220ba6cbb.jpg', null);
INSERT INTO `images` VALUES ('139', 'ff3b02be-b351-3684-ab91-7be0830e7a2c.jpg', null);
INSERT INTO `images` VALUES ('140', 'c8d78ea3-6ce0-329c-809f-475ec12de3ae.jpg', null);

-- ----------------------------
-- Table structure for intention_order
-- ----------------------------
DROP TABLE IF EXISTS `intention_order`;
CREATE TABLE `intention_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consumer_id` int(11) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pro_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `style_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `c_time` bigint(20) NOT NULL,
  `v1` varchar(255) DEFAULT NULL,
  `v2` varchar(255) DEFAULT NULL,
  `v3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of intention_order
-- ----------------------------
INSERT INTO `intention_order` VALUES ('2', '4', '13682430950', '574401729@qq.com', '1', '1', '1', '1', '21', '1524420838464', null, null, null);
INSERT INTO `intention_order` VALUES ('3', '4', '13682430950', '574401729@qq.com', '1', '1', '1', '1', '21', '1524448308558', null, null, null);
INSERT INTO `intention_order` VALUES ('4', '5', '15818522212', '1124546@qq.com', '1', '1', '1', '1', '21', '1524449731386', null, null, null);
INSERT INTO `intention_order` VALUES ('5', '6', '1311111111', '100000@qq.com', '4', '3', '4', '6', '24', '1524471799345', null, null, null);
INSERT INTO `intention_order` VALUES ('6', '7', '15888888888', '54545555@qq.com', '4', '3', '4', '6', '24', '1524475167319', null, null, null);
INSERT INTO `intention_order` VALUES ('7', '4', '13682430950', '574401729@qq.com', '4', '3', '4', '6', '24', '1524490596839', null, null, null);
INSERT INTO `intention_order` VALUES ('8', '4', '13682430950', '574401729@qq.com', '4', '3', '4', '6', '24', '1524490708402', null, null, null);

-- ----------------------------
-- Table structure for layout
-- ----------------------------
DROP TABLE IF EXISTS `layout`;
CREATE TABLE `layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `img_id` int(11) NOT NULL,
  `style_ids` varchar(100) DEFAULT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  `plan_ids` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of layout
-- ----------------------------
INSERT INTO `layout` VALUES ('1', '绝版三居130m2', '80', '1,2,3,4,6', null, null, null, '21,21,21,23,24');
INSERT INTO `layout` VALUES ('3', '精装2居95m2', '82', '2,3,4', null, null, null, '21,23,24');
INSERT INTO `layout` VALUES ('4', '带式输送机', '83', '1,4,6', null, null, null, '23,21,24');
INSERT INTO `layout` VALUES ('5', '地对地导弹', '84', '2,3,4', null, null, null, '21,23,24');
INSERT INTO `layout` VALUES ('7', '微风', '90', '2', null, null, null, '23');
INSERT INTO `layout` VALUES ('8', '虚线', '91', '3,4', null, null, null, '21,23');
INSERT INTO `layout` VALUES ('9', '肥肉', '92', '6', null, null, null, '24');
INSERT INTO `layout` VALUES ('11', '大苏打撒旦', '94', '8', null, null, null, '23');
INSERT INTO `layout` VALUES ('12', '大大苏打', '95', '4,6', null, null, null, '23,24');
INSERT INTO `layout` VALUES ('13', '大大', '96', '2', null, null, null, '24');
INSERT INTO `layout` VALUES ('14', '多大', '97', '6', null, null, null, '21');
INSERT INTO `layout` VALUES ('15', '阿德飒飒大苏打实打实', '98', '1', null, null, null, '23');
INSERT INTO `layout` VALUES ('16', '大苏打实打实打算电热毯我', '99', '4', null, null, null, '21');
INSERT INTO `layout` VALUES ('18', '飒飒', '124', '1,2', null, null, null, '21,23');
INSERT INTO `layout` VALUES ('19', '阿达', '125', '3,4,6,8,9,1,2', null, null, null, '23,24,21,21,21,21,21');

-- ----------------------------
-- Table structure for material
-- ----------------------------
DROP TABLE IF EXISTS `material`;
CREATE TABLE `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of material
-- ----------------------------
INSERT INTO `material` VALUES ('1', '黑色', null, null, null);
INSERT INTO `material` VALUES ('2', '黑白相间', null, null, null);
INSERT INTO `material` VALUES ('4', '黄色', null, null, null);
INSERT INTO `material` VALUES ('5', '紫色', null, null, null);
INSERT INTO `material` VALUES ('6', '七彩虹', null, null, null);
INSERT INTO `material` VALUES ('7', '实木', null, null, null);
INSERT INTO `material` VALUES ('8', '大红', null, null, null);
INSERT INTO `material` VALUES ('9', '大理石', null, null, null);
INSERT INTO `material` VALUES ('10', '玻璃', null, null, null);
INSERT INTO `material` VALUES ('11', '汉白玉', null, null, null);
INSERT INTO `material` VALUES ('12', '玉镶金', null, null, null);
INSERT INTO `material` VALUES ('13', 'uuuu', null, null, null);
INSERT INTO `material` VALUES ('14', 'uuu', null, null, null);
INSERT INTO `material` VALUES ('15', 'iii', null, null, null);
INSERT INTO `material` VALUES ('16', 'ooo', null, null, null);
INSERT INTO `material` VALUES ('17', 'ppp', null, null, null);
INSERT INTO `material` VALUES ('18', 'aaa', null, null, null);
INSERT INTO `material` VALUES ('19', 'sss', null, null, null);
INSERT INTO `material` VALUES ('20', 'fff', null, null, null);
INSERT INTO `material` VALUES ('22', 'ddd', null, null, null);
INSERT INTO `material` VALUES ('23', 'ggg', null, null, null);

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `form_where` varchar(255) NOT NULL,
  `c_time` bigint(20) NOT NULL,
  `content` text NOT NULL,
  `p_id` varchar(50) NOT NULL,
  `v1` varchar(255) DEFAULT NULL,
  `v2` varchar(255) DEFAULT NULL,
  `v3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `p_id_index` (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('n_1525019334716', '打拼的', '微信公众号', '1525019334000', '<div style=\"text-align:center;\">\r\n	按时发撒撒旦撒旦\r\n</div>', 'n_0_0', null, null, null);
INSERT INTO `news` VALUES ('n_1525020409686', '撒阿四发生', '飒飒', '1525020409000', '<div style=\"text-align:right;\">\r\n	的三个地方韩国军方\r\n</div>', 'n_0_1', null, null, null);
INSERT INTO `news` VALUES ('n_1525020840094', '萨达苏打水', '啊实打实的', '1525020840000', '<div style=\"text-align:center;\">\r\n	阿三大苏打ss\r\n</div>', 'n_0_2', null, null, null);
INSERT INTO `news` VALUES ('n_1525020871658', '啊实打实打算', '十大', '1525020871000', '<p style=\"text-align:center;\">\r\n	风格艺人身份的呢出现在曹\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	张新村自行车支持自行车自\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	行车v必须宣传部宣传部宣传部\r\n</p>', 'n_0_2', null, null, null);
INSERT INTO `news` VALUES ('n_1525021636947', '按时发送发放', '阿斯顿撒旦', '1525021637000', '<div style=\"text-align:center;\">\r\n	啊实打实大苏打&nbsp;\r\n</div>', 'n_0_1', null, null, null);
INSERT INTO `news` VALUES ('n_1525023664854', '鲁大师啊实', '萨达苏', '1525023664000', '<p style=\"text-align:center;\">\r\n	大苏打实打实\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"https://127.0.0.1:443/unn/upload/images/59888f3a-eeb6-3467-a8a5-1946f9d2e5a2.jpg\" alt=\"\" />\r\n</p>', 'n_1_0', null, null, null);
INSERT INTO `news` VALUES ('n_1525023750238', '反对法士大夫发', '发生飞洒发', '1525023750000', '<p style=\"text-align:center;\">\r\n	发生发生发生\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"https://127.0.0.1:443/unn/upload/images/b1a677c9-0cc1-3e26-afe4-cfa7995dc085.jpg\" alt=\"\" width=\"500\" height=\"375\" title=\"\" align=\"\" /> \r\n</p>', 'n_1_0', null, null, null);
INSERT INTO `news` VALUES ('n_1525023771576', '打算电', '大撒大撒', '1525023771000', '的撒旦', 'n_0_0', null, null, null);
INSERT INTO `news` VALUES ('n_1_2', '私人定制', '嘻嘻嘻嘻嘻嘻嘻', '1525023627000', '<img src=\"/unn/upload/images/f682059f-fd21-3513-bddf-d09799702ae2.jpg\" alt=\"\" /> \r\n<p style=\"text-align:center;\">\r\n	实打实大苏打大苏打是&nbsp; 的撒旦撒旦&nbsp; &nbsp;飞弹发射&nbsp; &nbsp; 的撒大苏打\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"https://127.0.0.1:443/unn/upload/images/8ff23cc4-898d-3849-aeb2-97dd6a5a3201.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<br />\r\n</p>\r\n<hr />\r\n<p style=\"text-align:center;\">\r\n	<a class=\"ke-insertfile\" href=\"https://127.0.0.1:443/unn/upload/images/ddc73539-655e-3cd8-ab0c-f4118a8fbaa2.zip\" target=\"_blank\">下载tomcat</a>\r\n</p>', 'n_1', null, null, null);
INSERT INTO `news` VALUES ('n_2', '公司简介', '微信', '1525023815000', '<h3 style=\"text-indent:2em;\">\r\n</h3>\r\n<h1>\r\n	<ul>\r\n		<li>\r\n			<span style=\"font-family:Arial;font-size:32px;color:#FF9900;\">标题</span> \r\n		</li>\r\n	</ul>\r\n</h1>\r\n<h1 style=\"text-indent:2em;\">\r\n	<table border=\"1\">\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					<h3>\r\n						标题1\r\n					</h3>\r\n				</td>\r\n				<td>\r\n					<h3>\r\n						标题1\r\n					</h3>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					内容1\r\n				</td>\r\n				<td>\r\n					内容2\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					内容3\r\n				</td>\r\n				<td>\r\n					内容4\r\n				</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</h1>\r\n<p style=\"text-indent:2em;\">\r\n	<img src=\"https://127.0.0.1:443/unn/upload/images/2f69390b-c2c3-3bec-8a49-be40d459501a.jpg\" alt=\"\" width=\"641\" height=\"639\" title=\"\" align=\"\" />\r\n</p>', 'n', null, null, null);
INSERT INTO `news` VALUES ('n_3', '联系我们', '微信公众号a', '1525014974000', '<hr style=\"page-break-after:always;\" class=\"ke-pagebreak\" />\r\n<p style=\"text-align:center;\">\r\n	顶顶顶顶顶顶顶顶顶顶顶顶\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/5429e73a-23a3-3bf9-9c38-0ed3deb6c37b.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/d755d953-aaa8-3d6c-9868-d6f493af7b1e.jpg\" alt=\"\" /><img src=\"/unn/upload/images/67b5c10c-d03b-3bbe-8f25-6c263550602d.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/af72e0e2-2b2b-3da1-8faa-ece063fc34f0.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/7730bf75-bac0-3fad-9b34-d71c024050f6.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/fc542c57-825c-37f1-83f6-a9a899fe1c2f.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/2ff3c27c-ad91-3aa1-991a-f9a6ffe89a32.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/5f4ab60e-69ca-3f19-95db-9f74c3a0dc8f.jpg\" alt=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/29ea1f17-19a0-3f2f-b969-43b49a3e23ef.jpg\" alt=\"\" /><img src=\"/unn/upload/images/d7a0abc5-7e68-322a-b678-a657eb21d588.jpg\" alt=\"\" width=\"200\" height=\"159\" title=\"\" align=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/6fe1dd8c-f4b0-3b02-95ee-144abf6946ae.jpg\" alt=\"\" width=\"200\" height=\"155\" title=\"\" align=\"\" /> \r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/unn/upload/images/2b651157-9a6e-344f-b9ce-b1c95193fa2b.jpg\" alt=\"\" width=\"200\" height=\"204\" title=\"\" align=\"\" /><img src=\"/unn/upload/images/b98a9df7-1603-351d-871e-65aa4386e876.jpg\" alt=\"\" width=\"200\" height=\"162\" title=\"\" align=\"\" /> \r\n</p>', 'n', null, null, null);

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_name` varchar(80) DEFAULT NULL,
  `consumer_id` int(11) NOT NULL,
  `intention_order_id` int(11) NOT NULL,
  `total_price` double(10,2) NOT NULL,
  `content` varchar(800) NOT NULL,
  `c_time` bigint(15) NOT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', null, '4', '2', '28000.00', '[{\"spaceId\": 4,\"furnList\": [{\"furnId\": 2,\"mId\": 20,\"count\": 2}]},{\"spaceId\": 1,\"furnList\": [{\"furnId\": 4, \"mId\": 8, \"count\": 1},{\"furnId\": 3, \"mId\": 16, \"count\": 2},{\"furnId\": 2, \"mId\": 20, \"count\": 3}]}]', '1524583397764', null, null, null);
INSERT INTO `order` VALUES ('2', null, '4', '2', '28000.00', '[{\"spaceId\": 4,\"furnList\": [{\"furnId\": 2,\"mId\": 20,\"count\": 2}]},{\"spaceId\": 1,\"furnList\": [{\"furnId\": 4, \"mId\": 8, \"count\": 1},{\"furnId\": 3, \"mId\": 16, \"count\": 2},{\"furnId\": 2, \"mId\": 20, \"count\": 3}]}]', '1524186906459', null, null, null);

-- ----------------------------
-- Table structure for plan
-- ----------------------------
DROP TABLE IF EXISTS `plan`;
CREATE TABLE `plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `content` varchar(800) DEFAULT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  `designer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of plan
-- ----------------------------
INSERT INTO `plan` VALUES ('21', '发咯', '[{\"spaceId\":4,\"imgId\":\"135\",\"hasFurnitureList\":[{\"id\":2,\"count\":\"2\"}]},{\"spaceId\":1,\"imgId\":\"136\",\"hasFurnitureList\":[{\"id\":4,\"count\":\"1\"},{\"id\":3,\"count\":\"2\"},{\"id\":2,\"count\":\"3\"}]},{\"spaceId\":3,\"imgId\":\"137\",\"hasFurnitureList\":[{\"id\":7,\"count\":\"1\"},{\"id\":5,\"count\":\"1\"},{\"id\":4,\"count\":\"1\"},{\"id\":2,\"count\":\"8\"}]}]', null, null, null, '5');
INSERT INTO `plan` VALUES ('23', '小二楼', '[{\"spaceId\":1,\"imgId\":\"76\",\"hasFurnitureList\":[{\"id\":5,\"count\":\"1\"},{\"id\":4,\"count\":\"3\"},{\"id\":3,\"count\":\"2\"}]},{\"spaceId\":2,\"imgId\":\"77\",\"hasFurnitureList\":[{\"id\":4,\"count\":\"1\"},{\"id\":2,\"count\":\"4\"}]},{\"spaceId\":3,\"imgId\":\"78\",\"hasFurnitureList\":[{\"id\":3,\"count\":\"1\"},{\"id\":2,\"count\":\"3\"}]}]', null, null, null, '3');
INSERT INTO `plan` VALUES ('24', '回国后', '[{\"spaceId\":1,\"imgId\":\"126\",\"hasFurnitureList\":[{\"id\":4,\"count\":\"1\"}]},{\"spaceId\":1,\"imgId\":\"127\",\"hasFurnitureList\":[{\"id\":5,\"count\":\"1\"}]}]', null, null, null, '8');
INSERT INTO `plan` VALUES ('25', '豪装', '[{\"spaceId\":3,\"imgId\":\"131\",\"hasFurnitureList\":[{\"id\":7,\"count\":\"1\"}]},{\"spaceId\":1,\"imgId\":\"132\",\"hasFurnitureList\":[{\"id\":3,\"count\":\"1\"},{\"id\":6,\"count\":\"2\"},{\"id\":2,\"count\":\"8\"}]}]', null, null, null, '1');

-- ----------------------------
-- Table structure for project
-- ----------------------------
DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `img_id` int(11) NOT NULL,
  `building_ids` varchar(100) DEFAULT NULL,
  `push` tinyint(4) NOT NULL DEFAULT '0',
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of project
-- ----------------------------
INSERT INTO `project` VALUES ('1', '万科金域蓝湾一期', '103', '1,2,5', '1', null, null, null);
INSERT INTO `project` VALUES ('3', '融创府二期', '105', '5', '1', null, null, null);
INSERT INTO `project` VALUES ('4', '观澜春日', '106', '3', '1', null, null, null);
INSERT INTO `project` VALUES ('5', '萝卜气', '128', '1,5', '0', null, null, null);

-- ----------------------------
-- Table structure for space
-- ----------------------------
DROP TABLE IF EXISTS `space`;
CREATE TABLE `space` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of space
-- ----------------------------
INSERT INTO `space` VALUES ('1', '厨房', null, null, null);
INSERT INTO `space` VALUES ('2', '客厅', null, null, null);
INSERT INTO `space` VALUES ('3', '卧室', null, null, null);
INSERT INTO `space` VALUES ('4', '卫生间', null, null, null);

-- ----------------------------
-- Table structure for style
-- ----------------------------
DROP TABLE IF EXISTS `style`;
CREATE TABLE `style` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  `v3` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of style
-- ----------------------------
INSERT INTO `style` VALUES ('1', '欧式', null, null, null);
INSERT INTO `style` VALUES ('2', '美式', null, null, null);
INSERT INTO `style` VALUES ('3', '古风', null, null, null);
INSERT INTO `style` VALUES ('4', '剑侠', null, null, null);
INSERT INTO `style` VALUES ('6', '中东', null, null, null);
INSERT INTO `style` VALUES ('8', '搭调', null, null, null);
INSERT INTO `style` VALUES ('9', '凤飞飞飞', null, null, null);
INSERT INTO `style` VALUES ('10', '发发发万', null, null, null);
INSERT INTO `style` VALUES ('11', '滴滴答答', null, null, null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` varchar(80) NOT NULL,
  `pwd` varchar(80) NOT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `ugroup` int(11) NOT NULL DEFAULT '1',
  `uname` varchar(80) DEFAULT NULL,
  `lastlogin` bigint(13) DEFAULT NULL,
  `error_time` int(5) NOT NULL DEFAULT '0',
  `v1` varchar(80) DEFAULT NULL,
  `v2` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', '0', '1', 'Administor', '1525103709281', '0', null, null);
